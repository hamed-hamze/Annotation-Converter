# undefined > DamagedApples_raw-images
https://public.roboflow.ai/object-detection/undefined

Provided by undefined
License: CC BY 4.0

## This project was created by Arfiani Nur Sayidah and is for sorting "apples" from "damaged apples."

The classes are "apple" and "damaged_apples"
**Original Class Balance:**
1. apple: 2,152
2. damaged_apple: 708