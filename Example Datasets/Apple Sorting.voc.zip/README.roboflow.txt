
Apple Sorting - v6 DamagedApples_raw-images
==============================

This dataset was exported via roboflow.ai on April 15, 2022 at 2:45 AM GMT

It includes 361 images.
Apple are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


