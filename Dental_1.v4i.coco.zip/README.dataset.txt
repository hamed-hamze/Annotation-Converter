# Dental_1 > 2024-03-27 1:17pm
https://universe.roboflow.com/petruxa/dental_1

Provided by a Roboflow user
License: CC BY 4.0

